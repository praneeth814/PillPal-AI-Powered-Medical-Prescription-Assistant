import { useState, useCallback } from "react";
import { Upload, FileText, X } from "lucide-react";

interface PrescriptionUploadProps {
  onUpload: (file: File) => void;
}

const PrescriptionUpload = ({ onUpload }: PrescriptionUploadProps) => {
  const [dragActive, setDragActive] = useState(false);
  const [fileName, setFileName] = useState<string | null>(null);

  const handleFile = useCallback(
    (file: File) => {
      if (file.type !== "application/pdf") return;
      setFileName(file.name);
      onUpload(file);
    },
    [onUpload]
  );

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setDragActive(false);
      if (e.dataTransfer.files[0]) handleFile(e.dataTransfer.files[0]);
    },
    [handleFile]
  );

  const clearFile = () => {
    setFileName(null);
  };

  return (
    <div className="w-full max-w-lg mx-auto">
      {!fileName ? (
        <label
          onDragOver={(e) => {
            e.preventDefault();
            setDragActive(true);
          }}
          onDragLeave={() => setDragActive(false)}
          onDrop={handleDrop}
          className={`relative flex flex-col items-center justify-center w-full h-64 rounded-2xl border-2 border-dashed cursor-pointer transition-smooth ${
            dragActive
              ? "border-primary bg-secondary shadow-glow"
              : "border-border bg-card hover:border-primary/50 hover:shadow-card"
          }`}
        >
          <input
            type="file"
            accept="application/pdf"
            className="hidden"
            onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])}
          />
          <div className="flex flex-col items-center gap-3 text-muted-foreground">
            <div className="w-14 h-14 rounded-xl gradient-hero flex items-center justify-center">
              <Upload className="w-6 h-6 text-primary-foreground" />
            </div>
            <div className="text-center">
              <p className="font-display font-semibold text-foreground">
                Upload prescription PDF
              </p>
              <p className="text-sm mt-1">
                Drag & drop or click to browse
              </p>
            </div>
            <div className="flex items-center gap-2 text-xs">
              <FileText className="w-3.5 h-3.5" />
              <span>PDF files supported</span>
            </div>
          </div>
        </label>
      ) : (
        <div className="relative rounded-2xl overflow-hidden shadow-card border border-border bg-card">
          <div className="flex items-center gap-4 p-6">
            <div className="w-14 h-14 rounded-xl bg-secondary flex items-center justify-center flex-shrink-0">
              <FileText className="w-7 h-7 text-primary" />
            </div>
            <div className="min-w-0 flex-1">
              <p className="font-display font-semibold text-foreground truncate">
                {fileName}
              </p>
              <p className="text-sm text-muted-foreground mt-0.5">
                PDF uploaded successfully
              </p>
            </div>
            <button
              onClick={clearFile}
              className="w-8 h-8 rounded-full bg-muted flex items-center justify-center hover:bg-muted/80 transition-smooth flex-shrink-0"
            >
              <X className="w-4 h-4 text-muted-foreground" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default PrescriptionUpload;
