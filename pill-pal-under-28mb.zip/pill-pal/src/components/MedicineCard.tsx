import { Clock, Check, Pill } from "lucide-react";
import { useState } from "react";

export interface Medicine {
  id: string;
  name: string;
  dosage: string;
  frequency: string;
  times: string[];
  color: "blue" | "pink" | "amber" | "green";
  taken: boolean[];
}

const colorMap = {
  blue: "bg-medicine-blue/15 text-medicine-blue border-medicine-blue/30",
  pink: "bg-medicine-pink/15 text-medicine-pink border-medicine-pink/30",
  amber: "bg-medicine-amber/15 text-medicine-amber border-medicine-amber/30",
  green: "bg-medicine-green/15 text-medicine-green border-medicine-green/30",
};

const dotMap = {
  blue: "bg-medicine-blue",
  pink: "bg-medicine-pink",
  amber: "bg-medicine-amber",
  green: "bg-medicine-green",
};

interface MedicineCardProps {
  medicine: Medicine;
  onToggleTaken: (medId: string, timeIndex: number) => void;
}

const MedicineCard = ({ medicine, onToggleTaken }: MedicineCardProps) => {
  return (
    <div className="rounded-2xl border border-border bg-card p-5 shadow-card hover:shadow-card-hover transition-smooth">
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${colorMap[medicine.color]}`}>
            <Pill className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-display font-semibold text-foreground">{medicine.name}</h3>
            <p className="text-sm text-muted-foreground">{medicine.dosage}</p>
          </div>
        </div>
        <span className={`text-xs font-medium px-2.5 py-1 rounded-full border ${colorMap[medicine.color]}`}>
          {medicine.frequency}
        </span>
      </div>

      <div className="flex flex-wrap gap-2">
        {medicine.times.map((time, i) => (
          <button
            key={i}
            onClick={() => onToggleTaken(medicine.id, i)}
            className={`flex items-center gap-2 px-3 py-2 rounded-xl text-sm font-medium transition-smooth border ${
              medicine.taken[i]
                ? "bg-primary/10 text-primary border-primary/30"
                : "bg-muted text-muted-foreground border-border hover:border-primary/30"
            }`}
          >
            {medicine.taken[i] ? (
              <Check className="w-3.5 h-3.5" />
            ) : (
              <Clock className="w-3.5 h-3.5" />
            )}
            {time}
          </button>
        ))}
      </div>
    </div>
  );
};

export default MedicineCard;
