import { useState } from "react";
import { Sparkles, ArrowRight, Pill, Bell, Shield, FileText } from "lucide-react";
import PrescriptionUpload from "@/components/PrescriptionUpload";
import MedicineCard, { Medicine } from "@/components/MedicineCard";
import { extractTextFromPdf } from "@/lib/pdfExtractor";
import { parsePrescriptionText } from "@/lib/prescriptionParser";
import { toast } from "sonner";
import heroImage from "@/assets/hero-illustration.png";

const Index = () => {
  const [medicines, setMedicines] = useState<Medicine[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [hasUploaded, setHasUploaded] = useState(false);
  const [extractedText, setExtractedText] = useState<string>("");

  const handleUpload = async (file: File) => {
    setIsProcessing(true);
    toast.info("Extracting text from your prescription...");

    try {
      const text = await extractTextFromPdf(file);
      setExtractedText(text);

      if (!text.trim()) {
        toast.error("Could not extract text from this PDF. It may be a scanned image.");
        setIsProcessing(false);
        return;
      }

      const parsed = parsePrescriptionText(text);

      if (parsed.length === 0) {
        toast.error("No medications found in the PDF. Please check the document.");
        setIsProcessing(false);
        return;
      }

      setMedicines(parsed);
      setHasUploaded(true);
      toast.success(`Found ${parsed.length} medication(s)!`);
    } catch (err) {
      console.error("PDF parsing error:", err);
      toast.error("Failed to read the PDF. Please try another file.");
    } finally {
      setIsProcessing(false);
    }
  };

  const handleToggleTaken = (medId: string, timeIndex: number) => {
    setMedicines((prev) =>
      prev.map((m) => {
        if (m.id !== medId) return m;
        const newTaken = [...m.taken];
        newTaken[timeIndex] = !newTaken[timeIndex];
        return { ...m, taken: newTaken };
      })
    );
  };

  const takenCount = medicines.reduce(
    (acc, m) => acc + m.taken.filter(Boolean).length,
    0
  );
  const totalCount = medicines.reduce((acc, m) => acc + m.taken.length, 0);

  return (
    <div className="min-h-screen gradient-subtle">
      {/* Header */}
      <header className="border-b border-border bg-card/80 backdrop-blur-md sticky top-0 z-50">
        <div className="container max-w-5xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg gradient-hero flex items-center justify-center">
              <Pill className="w-4 h-4 text-primary-foreground" />
            </div>
            <span className="font-display font-bold text-lg text-foreground">
              MedRemind
            </span>
          </div>
          {hasUploaded && totalCount > 0 && (
            <div className="text-sm text-muted-foreground">
              <span className="font-semibold text-primary">{takenCount}</span>
              <span> / {totalCount} doses taken</span>
            </div>
          )}
        </div>
      </header>

      <main className="container max-w-5xl mx-auto px-4 py-8">
        {/* Hero section */}
        {!hasUploaded && !isProcessing && (
          <section className="text-center mb-12">
            <div className="max-w-2xl mx-auto mb-8">
              <img
                src={heroImage}
                alt="Medicine reminder illustration with clock and pills"
                className="w-full max-w-md mx-auto rounded-2xl mb-8"
              />
              <h1 className="font-display text-4xl md:text-5xl font-extrabold text-foreground mb-4 leading-tight">
                Never miss a dose again
              </h1>
              <p className="text-lg text-muted-foreground max-w-lg mx-auto">
                Upload your prescription PDF and we'll extract medications and
                create a simple reminder schedule for you.
              </p>
            </div>

            {/* Feature pills */}
            <div className="flex flex-wrap justify-center gap-3 mb-10">
              {[
                { icon: FileText, label: "PDF text extraction" },
                { icon: Sparkles, label: "Smart parsing" },
                { icon: Bell, label: "Easy reminders" },
                { icon: Shield, label: "Private & secure" },
              ].map(({ icon: Icon, label }) => (
                <div
                  key={label}
                  className="flex items-center gap-2 px-4 py-2 rounded-full bg-secondary text-secondary-foreground text-sm font-medium"
                >
                  <Icon className="w-4 h-4" />
                  {label}
                </div>
              ))}
            </div>

            <PrescriptionUpload onUpload={handleUpload} />

            <p className="text-xs text-muted-foreground mt-4">
              Upload a <strong>PDF</strong> prescription. Text will be extracted
              and medications parsed automatically.
            </p>
          </section>
        )}

        {/* Processing state */}
        {isProcessing && (
          <div className="flex flex-col items-center justify-center py-20">
            <div className="w-16 h-16 rounded-2xl gradient-hero flex items-center justify-center mb-4 animate-pulse">
              <Sparkles className="w-7 h-7 text-primary-foreground" />
            </div>
            <p className="font-display font-semibold text-foreground">
              Extracting & parsing prescription...
            </p>
            <p className="text-sm text-muted-foreground mt-1">
              Reading your PDF
            </p>
          </div>
        )}

        {/* Medicine list */}
        {hasUploaded && !isProcessing && medicines.length > 0 && (
          <section>
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="font-display text-2xl font-bold text-foreground">
                  Your Medicines
                </h2>
                <p className="text-sm text-muted-foreground mt-1">
                  Tap a time to mark as taken
                </p>
              </div>
              <button
                onClick={() => {
                  setHasUploaded(false);
                  setMedicines([]);
                  setExtractedText("");
                }}
                className="flex items-center gap-1.5 text-sm font-medium text-primary hover:underline"
              >
                Upload new <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Progress bar */}
            {totalCount > 0 && (
              <div className="mb-6">
                <div className="h-2 rounded-full bg-muted overflow-hidden">
                  <div
                    className="h-full rounded-full gradient-hero transition-all duration-500"
                    style={{
                      width: `${(takenCount / totalCount) * 100}%`,
                    }}
                  />
                </div>
              </div>
            )}

            <div className="grid gap-4 md:grid-cols-2">
              {medicines.map((med) => (
                <MedicineCard
                  key={med.id}
                  medicine={med}
                  onToggleTaken={handleToggleTaken}
                />
              ))}
            </div>

            {/* Extracted text preview */}
            {extractedText && (
              <details className="mt-8">
                <summary className="text-sm text-muted-foreground cursor-pointer hover:text-foreground transition-smooth">
                  View extracted text
                </summary>
                <pre className="mt-3 p-4 rounded-xl bg-muted text-xs text-muted-foreground whitespace-pre-wrap max-h-60 overflow-auto border border-border">
                  {extractedText}
                </pre>
              </details>
            )}
          </section>
        )}
      </main>
    </div>
  );
};

export default Index;
