import { Medicine } from "@/components/MedicineCard";

export const DEMO_MEDICINES: Medicine[] = [
  {
    id: "1",
    name: "Amoxicillin",
    dosage: "500mg capsule",
    frequency: "3x daily",
    times: ["8:00 AM", "2:00 PM", "8:00 PM"],
    color: "blue",
    taken: [false, false, false],
  },
  {
    id: "2",
    name: "Ibuprofen",
    dosage: "200mg tablet",
    frequency: "As needed",
    times: ["After meals"],
    color: "pink",
    taken: [false],
  },
  {
    id: "3",
    name: "Vitamin D3",
    dosage: "1000 IU",
    frequency: "1x daily",
    times: ["9:00 AM"],
    color: "amber",
    taken: [false],
  },
  {
    id: "4",
    name: "Metformin",
    dosage: "850mg tablet",
    frequency: "2x daily",
    times: ["8:00 AM", "8:00 PM"],
    color: "green",
    taken: [false, false],
  },
];
