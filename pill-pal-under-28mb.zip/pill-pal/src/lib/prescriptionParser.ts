import { Medicine } from "@/components/MedicineCard";

const COLORS: Medicine["color"][] = ["blue", "pink", "amber", "green"];

// Common medicine keywords to help identify medication lines
const DOSAGE_PATTERNS = /(\d+\s*(?:mg|mcg|ml|g|iu|units?|tab(?:let)?s?|cap(?:sule)?s?))/i;
const TIME_PATTERN = /(\d{1,2}:\d{2}\s*(?:am|pm)?)/gi;
const FREQUENCY_PATTERNS: { pattern: RegExp; label: string; defaultTimes: string[] }[] = [
  { pattern: /three times\s*(?:a|per)\s*day|tid|3\s*x\s*daily|thrice daily/i, label: "3x daily", defaultTimes: ["8:00 AM", "2:00 PM", "8:00 PM"] },
  { pattern: /twice\s*(?:a|per)\s*day|bid|2\s*x\s*daily|two times/i, label: "2x daily", defaultTimes: ["8:00 AM", "8:00 PM"] },
  { pattern: /once\s*(?:a|per)\s*day|od|1\s*x\s*daily|daily|every\s*day/i, label: "1x daily", defaultTimes: ["9:00 AM"] },
  { pattern: /every\s*(\d+)\s*hours?/i, label: "Every few hours", defaultTimes: ["8:00 AM", "2:00 PM", "8:00 PM"] },
  { pattern: /as\s*needed|prn|when\s*required/i, label: "As needed", defaultTimes: ["As needed"] },
  { pattern: /at\s*(?:bed\s*time|night|hs)/i, label: "At bedtime", defaultTimes: ["10:00 PM"] },
  { pattern: /(?:before|with|after)\s*meals?/i, label: "With meals", defaultTimes: ["8:00 AM", "1:00 PM", "7:00 PM"] },
];

function extractFrequencyAndTimes(line: string): { frequency: string; times: string[] } {
  // First check for explicit times in the text
  const explicitTimes = line.match(TIME_PATTERN);

  for (const { pattern, label, defaultTimes } of FREQUENCY_PATTERNS) {
    if (pattern.test(line)) {
      return {
        frequency: label,
        times: explicitTimes && explicitTimes.length > 0 ? explicitTimes : defaultTimes,
      };
    }
  }

  // Default
  return {
    frequency: "1x daily",
    times: explicitTimes && explicitTimes.length > 0 ? explicitTimes : ["9:00 AM"],
  };
}

export function parsePrescriptionText(text: string): Medicine[] {
  const lines = text.split(/\n|\.|\;/).map((l) => l.trim()).filter(Boolean);
  const medicines: Medicine[] = [];
  let id = 0;

  for (const line of lines) {
    // Look for lines that contain dosage info (strong signal of a medication line)
    const dosageMatch = line.match(DOSAGE_PATTERNS);
    if (!dosageMatch) continue;

    // Try to extract the medicine name (text before the dosage)
    const dosageIndex = line.indexOf(dosageMatch[0]);
    let name = line.substring(0, dosageIndex).trim();

    // Clean up common prefixes like "Tab.", "Cap.", numbers, bullets
    name = name.replace(/^[\d\.\)\-\*•]+\s*/, "").replace(/^(tab\.?|cap\.?|inj\.?|syp\.?|syr\.?)\s*/i, "").trim();

    if (!name || name.length < 2 || name.length > 60) continue;

    // Capitalize first letter
    name = name.charAt(0).toUpperCase() + name.slice(1);

    const dosage = dosageMatch[0];
    const afterDosage = line.substring(dosageIndex + dosageMatch[0].length);
    const { frequency, times } = extractFrequencyAndTimes(afterDosage || line);

    medicines.push({
      id: String(++id),
      name,
      dosage,
      frequency,
      times,
      color: COLORS[id % COLORS.length],
      taken: times.map(() => false),
    });
  }

  return medicines;
}
